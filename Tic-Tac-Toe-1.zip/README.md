# Tic-Tac-Toe
Tic Tac Toe game with invalid-input-flags for invalid data type entry from user (Program won't go nuts if a character is entered instead of an integer) 
and also Single / Multi - Player options....
😁❌⭕ 

# Instructions
Import the code into something such as Visual Studio Code or Replit to use the terminal to play.